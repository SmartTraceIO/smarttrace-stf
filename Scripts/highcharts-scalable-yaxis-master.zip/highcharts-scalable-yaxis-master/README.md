Highcharts Scalable Y-Axis
=========================

Using this plugin lets the user manually adjust Y-Axis range by dragging the labels.
Double click to go back to default range.

To disable, set scalable = false. Default is true.

<pre>
yAxis: {
    scalable: false
}
</pre>

Can also be used with Highstock.

Demo:
http://www.highcharts.com/plugin-registry/single/20/Scalable%20Y-Axis

Donate
---
Bitcoin to <code>15dv1MW6LrArfzrzq46mPscjce7vLUfaBR</code>
